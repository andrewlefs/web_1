﻿<div class="col-md-9 g-home" role="main">
<ul class="nav nav-tabs mobile" id="mobileTab">
  <li class="active"><a href="" data-toggle="tab">Liên hệ</a></li>
  <li><a href="./gioithieu">Giới thiệu</a></li>
  <li><a href="./huongdan">Hướng dẫn</a></li>
  <li><a href="./chietkhau">Chiết khấu</a></li>
</ul>


<div class="pay-info">Thông tin liên hệ: <strong><br />
  CÔNG TY CỔ PHẦN CÔNG NGHỆ SỐ SAO VIỆT <br />
</strong><strong><strong>Tầng 5, Tòa nhà 137 Hoàng Quốc Việt, Cầu Giấy, Hà Nội. </strong></strong><br />
W: www.svcorp.vn - www.pay123.vn | E: pay123@svcorp.vn<br />
Điện thoại: (04)3839.8674 - (04)6291.9135 - Fax: (04)6684.9158<br />
<br />
Sơ đồ đường đi:<br />
<img src="http://www.svcorp.vn/images/sodo.png" alt="" width="494" height="456" /></div>

</div>
