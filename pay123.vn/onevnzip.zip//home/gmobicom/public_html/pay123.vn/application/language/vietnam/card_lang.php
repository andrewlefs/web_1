<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
$lang['card_mobile'] ="Thẻ điện thoại";
$lang['card_mobile1'] ="Viettel";
$lang['card_mobile2'] ="Mobifone";
$lang['card_mobile3'] ="Vinaphone";

$lang['card_game'] ="Thẻ game";
$lang['card_game1'] ="Gate Card";
$lang['card_game2'] ="Vcoin";
$lang['card_game3'] ="Zingcard";
$lang['card_game4'] ="OnCard";
$lang['card_game5'] ="VGold";

/* End of file card_lang.php */
/* Location: ./system/language/vietnam/card_lang.php */