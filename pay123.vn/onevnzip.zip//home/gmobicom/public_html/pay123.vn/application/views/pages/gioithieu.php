﻿<div class="col-md-9 g-home" role="main">
<ul class="nav nav-tabs mobile" id="mobileTab">
  <li class="active"><a href="" data-toggle="tab">Tin tức</a></li>
  <li class="active"><a href="./gioithieu">Giới thiệu</a></li>
  <li><a href="./huongdan">Hướng dẫn</a></li>
  <li><a href="./chietkhau">Chiết khấu</a></li>
</ul>


<div class="pay-info">Hiện Pay123.vn cung cấp các dịch vụ sau:
  <p>- Nạp tiền điện thoại trực tiếp (topup) cho thuê bao di động.<br />
      <br />
    - Mua mã thẻ điện thoại và mã thẻ Game;
    <br />
      <br />
    - Bạn có thể trở thành Đại lý của Pay123, dùng tiền PayXu trong tài khoản đại lý để nạp tiền điện thoại - mua mã thẻ cào cho bạn bè, người thân hoặc khách hàng của mình một cách dễ dàng và được hưởng chiết khấu tốt hơn so với thông thường.<br />
    <br />
    - Khi bạn nạp tiền điện thoại tại Pay123.vn, bạn vẫn được hưởng toàn bộ các chương trình khuyến mại của nhà mạng dành cho các thuê bao.<br />
    <br />
    - Ngoài khuyến mại của nhà mạng, bạn còn được hưởng chính sách chiết khấu thường xuyên của Pay123 từ 3% đến 5% trên mỗi giao dịch.<br />
  <br />
    Chúc bạn luôn thấy thoải mái khi sử dụng dịch vụ tại Pay123.vn</p>
  </div>

</div>
