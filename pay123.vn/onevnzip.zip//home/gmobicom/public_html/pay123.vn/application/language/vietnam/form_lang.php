<?php
$lang['form_notice'] = 'Bài viết có tiêu đề tương tự:';
$lang['form_notice_content'] = 'Bạn nên xem phần này để tránh việc post bài đã có trên website';