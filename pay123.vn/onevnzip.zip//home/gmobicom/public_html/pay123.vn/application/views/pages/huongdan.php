﻿<div class="col-md-9 g-home" role="main">
<ul class="nav nav-tabs mobile" id="mobileTab">
  <li class="active"><a href="" data-toggle="tab">Hướng dẫn</a></li>
  <li><a href="./gioithieu">Giới thiệu</a></li>
  <li class="active"><a href="./huongdan">Hướng dẫn</a></li>
  <li><a href="./chietkhau">Chiết khấu</a></li>
</ul>


<div class="pay-info">
  <h4>Hướng dẫn mua thẻ cào trực tuyến</h4>
  <div>
    <p>Hướng dẫn sau đây được thực hiện sau khi các bạn <a href="../auth/login">đăng nhập</a>. Nếu chưa có tài khoản hãy bấm <a href="../auth/register">vào đây </a>để đăng ký.<br />
      <br />
      Khách hàng chọn mua sản phẩm theo cách sau:</p>
    <h4><strong>Bước 1: Chọn sản phẩm</strong></h4>
    <ul>
      <li>Chọn thẻ cào bạn muốn mua.</li>
    </ul>
    <p>
      <input name="image" type="image" src="http://pay123.vn/theme/images/1.png" width="600" />
    </p>
    </div>
  <div>
    <h4><strong>Bước 2: Thanh toán</strong></h4>
    <ul>
      <li>Chọn Thanh Toán để trả tiền cho sản phẩm bạn đã mua</li>
    </ul>
    <p>
      <input name="image2" type="image" src="http://pay123.vn/theme/images/2.png" width="600" />
    </p>
    <p>trong lúc các bạn lựa chọn thẻ vẫn có thể thanh toán thẻ bằng menu trên tay trái của trang chủ </p>
    </div>
  <div><br />
      <ul>
        <li>Lựa chọn phương thức thanh toán:</li>
      </ul>
    <input name="image2" type="image" src="http://pay123.vn/theme/images/3.png" width="600" />
  </div>
</div>

</div>
