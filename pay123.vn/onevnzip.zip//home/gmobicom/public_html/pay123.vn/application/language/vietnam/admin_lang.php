<?php
$lang['admin_title']			= "Bảng điều khiển";
$lang['admin_project_name'] 	= "Từ điển nông nghiệp";
$lang['admin_system'] 			= "Hệ thống";
$lang['admin_wikis'] 			= "Wikis";
$lang['admin_categories']		= "Danh mục";
$lang['admin_parent_id']		= "ID cha";
$lang['admin_id']				= "ID";
$lang['admin_action'] 			= "Thao tác";
$lang['admin_add_new'] 			= "Thêm mới";
$lang['admin_delete'] 			= "Xóa";
$lang['admin_view_edit'] 		= "Xem & sửa";
$lang['admin_add_category'] 	= "Thêm danh mục";

$lang['admin_search'] 			= "Tìm kiếm";
$lang['admin_filter'] 			= "Lọc theo ";
$lang['admin_order_by'] 		= "Sắp xếp";



$lang['admin_name'] 			= "Tên";
$lang['admin_description'] 		= "Miêu tả ngắn gọn";
$lang['admin_parent_category'] 	= "Thuộc danh mục";
$lang['admin_no_parent_category'] = "Là danh mục chính";
$lang['admin_content'] = "Nội dung";
/* End of file admin_lang.php */
/* Location: ./system/language/vietnam/admin_lang.php */ 