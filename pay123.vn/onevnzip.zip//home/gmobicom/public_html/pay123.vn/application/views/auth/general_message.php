﻿<div class="col-md-9" role="main">
<ul class="nav nav-tabs mobile" id="mobileTab">
  <li class="active"><a href="" data-toggle="tab">Thông báo</a></li>
  <li><a href="../gioithieu">Giới thiệu</a></li>
  <li><a href="../huongdan">Hướng dẫn</a></li>
  <li><a href="../chietkhau">Chiết khấu</a></li>
</ul>

<div class="pay-info">
<div class="page-header"><h4><?php echo $message;?></h4></div>
Cảm ơn bạn đã sử dụng dịch vụ! Chúc bạn vui vẻ!<BR />
Trân trọng!
</div>
</div>