<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="<?php echo ''.$this->config->base_url().'theme/js/bootstrap.min.js';?>"></script>
  </body>
</html>
