<?php

$lang['shop_gio']		= 'Giỏ hàng';
$lang['shop_thanhtoan'] = 'Thanh toán';
$lang['shop_rong']		= 'Giỏ hàng hiện đang trống';

/* End of file shop_lang.php */
/* Location: ./system/language/vietnam/shop_lang.php */