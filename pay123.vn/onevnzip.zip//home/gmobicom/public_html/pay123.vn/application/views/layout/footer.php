	  </div><!--End Container -->
	<div class="gfooter container"> 
		<div class="row">
			<div class="col-md-4">
				
				<p><strong>CÔNG TY CP CÔNG NGHỆ SỐ SAO VIỆT</strong><br>
				<span style="font-size: 12px">Địa chỉ: Tầng 5, 137 Hoàng Quốc Việt, Cầu Giấy, HN.<br>
				Điện thoại: 0466849158 | Email: info@pay123.vn<br>
				Hỗ trợ: <a href="./huongdan">Hướng dẫn</a> - <a href="./lienhe">Liên hệ</a> - <a href="./chietkhau">Chiết khấu</a></span></p>
			</div>
			<div class="col-md-8" style="margin-top: -20px">
				<strong>Các giao dịch được đảm bảo bởi:</strong>
				<span class="dambao"></span>
				<br>
				<span class="nganhang"></span>
			</div>
		</div>
	</div>
  </div><!--End Container -->
  </div><!--End Bao -->
  </body>
</html>