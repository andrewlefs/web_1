<div class="col-md-9 g-home" role="main">
<ul class="nav nav-tabs mobile" id="mobileTab">
  <li class="active"><a href="" data-toggle="tab">Thông báo</a></li>
  <li><a href="./gioithieu">Giới thiệu</a></li>
  <li><a href="./huongdan">Hướng dẫn</a></li>
  <li><a href="./chietkhau">Chiết khấu</a></li>
</ul>

<div class="pay-info">
<p>
Xin lỗi, chúng tôi đang cập nhật kho thẻ, bạn hãy giữ nguyên trang này và ấn Tải lại trang sau ít phút để nhận mã thẻ
</p>
</div>
</div>