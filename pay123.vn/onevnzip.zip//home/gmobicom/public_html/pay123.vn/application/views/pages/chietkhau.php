﻿<div class="col-md-9 g-home" role="main">
<ul class="nav nav-tabs mobile" id="mobileTab">
  <li class="active"><a href="" data-toggle="tab">Chiết khấu</a></li>
  <li><a href="./gioithieu">Giới thiệu</a></li>
  <li><a href="./huongdan">Hướng dẫn</a></li>
  <li class="active"><a href="./chietkhau">Chiết khấu</a></li>
</ul>


<div class="pay-info">

Bảng chiết khấu tại Pay123.vn: <br />
  <img  src="../theme/images/chietkhau.png" /></div>

</div>
