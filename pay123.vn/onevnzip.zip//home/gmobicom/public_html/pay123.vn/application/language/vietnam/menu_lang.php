<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['menu_home'] = 'Mua thẻ điện thoại - mua thẻ game';
$lang['menu_hoadon'] = 'Thanh toán hóa đơn';
$lang['menu_quatang'] = 'Quà tặng';
$lang['menu_taikhoan'] = 'Tài khoản';
$lang['menu_tintuc'] = 'Tin tức';
$lang['menu_dangki'] = 'Đăng ký';
$lang['menu_dangnhap'] = 'Đăng nhập';
$lang['menu_quenpass'] = 'Quên mật khẩu';