<?php
		@session_start();

			?>
            <style type="text/css">
<!--
do {
	color: #F00;
}
-->
            </style>
<div class="menu">
	<img src="images/iconmoney.png" alt="">
	Bổ Sung thanh toán </div>
<div id="noidungtin" charset=UTF-8>
  <div><span style="color:#000099">
    Chào các bạn!<br />
    <br />
    Nhằm  phục vụ tốt hơn trong việc thanh toán, từ tháng 11/2013 Xác Nhận bổ sung thêm ngân hàng <strong>Vietinbank</strong> vào hệ thống ngân hàng của công ty.<br />
    <br />
    <strong>Theo đó,</strong> XNN sử dụng 03 tài khoản thanh toán gồm: Vietinbank, Vietcombank, Dongabank.
    <br />
<br />
<strong>Thông tin thêm:</strong> Ngân hàng Vietcombank &amp; Dongabank là ngân hàng nhà nước nên thường chỉ làm việc đến 16h00 hàng ngày, và không làm việc thứ 7. Còn ngân hàng Vietinbank là ngân hàng tư nhân nên làm việc đến 17h30 hàng ngày và có làm việc thứ 7. Do đó, việc thêm ngân hàng Vietinbank vào hệ thống ngân hàng sẽ làm cho việc thanh toán định kỳ có thể giảm xuống chỉ còn 01 ngày là hoàn tất.</span><br />
<br />
<span style="color:#000099"><strong>Công việc của thành viên:</strong> Nếu có tài khoản Vietinbank thì bạn nên <a href="./index.php?mod=taikhoan">cập nhật</a> lại để sử dụng, nhất là những bạn có doanh thu cao. Thứ tự ưu tiên các ngân hàng như sau: Vietinbank =&gt; Vietcombank =&gt; DongaBank =&gt; Khác.<br />
<br />
Trân trọng &amp; Cảm ơn! </span>
<div>
  <div align="left"><br clear="all" />
  </div>
</div>
  </div>
</div>

            <?php
?>
