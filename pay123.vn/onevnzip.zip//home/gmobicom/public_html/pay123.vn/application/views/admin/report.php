<div class="page-header"><h1><?php echo ''.$title.'';?></h1></div>
<?php echo $notice;?>