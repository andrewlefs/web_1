<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
	<div class="jumbotron">
        <h1><?php echo $title;?></h1>
        <p>Chúc anh một ngày làm việc thành công và vui vẻ.</p>
        <p>Cùng xem qua thống kê doanh thu xem sao.</p>
        <p>
		<!-- Button trigger modal -->
		<a href="http://pay123.vn/lau5goc/thongketuan" class="btn btn-primary btn-lg extra-center" data-toggle="modal">
		  Xem luôn...
		</a>
        </p>
      </div>
<?php
/* End of file main.php */
/* Location: ./application/views/configuration/main.php */