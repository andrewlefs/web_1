
    <table cellspacing="0" cellpadding="4">
        <tbody>
            <tr>
              <td width="100%" align="center">
                    <p><br/>
                      <span class="doanh_thu">NỘI QUY SVCORP </span></p>
                    <p align="left"><span class="style1">Quy định về thời gian làm việc:<br>
                      - Sáng 8h15 - 12h<br>
                      - Chiều 1h30 - 5h30 CH <br>
                    <br>
                      Quy định về ngủ trưa
                    <br>
                    - Thời gian ngủ trưa bắt đầu từ 12h45 - 13h15.<br>
                    - Trong khoảng thời gian trên tất cả mọi người đều phải ngủ trưa, không làm việc riêng để ảnh hưởng đến người khác và chiều lấy sức làm việc.<br>
                    <br>
                    Quy định về đi muộn:<br>
                    - Khi đi muộn sẽ xin trước giờ làm việc với Khanh ( 0973 448 522 ).<br>
                    - Ngoài ra xin phép thêm trưởng phòng ( nếu cần ) để không ảnh hưởng đến công việc.<br>
                    - Phạt đi muộn: <br>
                    +
                    Dưới 10 phút: 5.000 đồng; <br>
                    + 
                    Trên 10 phút: 10.000 đồng. <br>
                    Đi muộn không phép phạt tăng gấp đôi. <br>
                    <br>
                    Quy định về ra ngoài trong giờ làm việc:<br>
                    - Ra ngoài làm việc riêng: 
                    xin Khanh.<br>
                    - Ra ngoài theo chỉ thị của cấp trên hoặc việc công ty: báo Khanh. <br>
                    - Phạt ra ngoài làm việc riêng: <br>
                    + Dưới 15 phút: Không phạt;<br>
                    + Trên 15 phút: 5.000 đồng;<br>
                    + Trên 30 phút: 10.000 đồng;<br>
                    Ra ngoài không phép phạt tăng gấp đôi.<br>
                    <br>
                    Quy định về nghỉ làm:<br>
                    - Nghỉ làm việc xin phép Nghĩa. ( 0987 42 3333 )
                    <br>
                    - Xin trước 1 ngày với nghỉ nửa ngày.<br>
                    - Xin trước 2 ngày với nghỉ cả ngày.<br>
                    - Phạt nghỉ làm:<br>
                    + Quy định: lương cơ bản  / 25 ngày = x.<br>
                    + Nghỉ cả ngày: 
                     x đồng.<br>
                    + Nghỉ nửa ngày: x/2 đồng.
                    <br>
                    + Sáng thứ 7 tính là cả ngày. <br>
                    Nghỉ không xin phép phạt tăng gấp đôi.<br>
                    <br>
                    Quy định về vệ sinh:<br>
                    - Vệ sinh theo sự quản lý của Thế Anh.<br>
                    - Trường hợp đến phiên vệ sinh của mình mà nghỉ thì báo cho Thế Anh.
                    </span><br>
                    <br>
                  </p></td>
            </tr>
        </tbody>
    </table> 

         