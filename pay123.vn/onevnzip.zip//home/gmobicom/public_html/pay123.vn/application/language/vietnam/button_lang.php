<?php
$lang['button_logout'] = "Thoát";
$lang['button_save'] = "Lưu lại";
$lang['button_cancel'] = "Hủy";
$lang['button_back_to_top'] = "Lên đầu trang";
/* End of file button_lang.php */
/* Location: ./system/language/vietnam/button_lang.php */ 