<?php
	$this->load->view('admin/layout/header');
	$this->load->view($main_template);
	$this->load->view('admin/layout/footer');